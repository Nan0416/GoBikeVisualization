run the following
    python3 -m http.server
open http://localhost:8000